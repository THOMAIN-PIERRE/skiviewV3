import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-recapitulatif',
  templateUrl: './recapitulatif.component.html',
  styleUrls: ['./recapitulatif.component.css']
})
export class RecapitulatifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
