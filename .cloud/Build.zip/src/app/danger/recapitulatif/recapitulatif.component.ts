import { Component, OnInit } from '@angular/core';
import * as geolocation from "nativescript-geolocation";
import { Accuracy } from "tns-core-modules/ui/enums"; // used to describe at what accuracy the location should be get

@Component({
  selector: 'ns-recapitulatif',
  templateUrl: './recapitulatif.component.html',
  styleUrls: ['./recapitulatif.component.css']
})
export class RecapitulatifComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
    geolocation.enableLocationRequest()
    .then(()=> {
      geolocation.getCurrentLocation({ desiredAccuracy: Accuracy.high, maximumAge: 5000, timeout: 20000 })
      .then((location)=> {
        alert(JSON.stringify(location));
      })  
    })
  }
}
