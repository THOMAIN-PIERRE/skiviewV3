import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-fiche-signalement',
  templateUrl: './fiche-signalement.component.html',
  styleUrls: ['./fiche-signalement.component.css']
})
export class FicheSignalementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
