import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-confirmation-envoi',
  templateUrl: './confirmation-envoi.component.html',
  styleUrls: ['./confirmation-envoi.component.css']
})
export class ConfirmationEnvoiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
