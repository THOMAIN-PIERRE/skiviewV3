import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-photo2',
  templateUrl: './photo2.component.html',
  styleUrls: ['./photo2.component.css']
})
export class Photo2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
