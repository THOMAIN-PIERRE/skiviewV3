import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-historique-signalement',
  templateUrl: './historique-signalement.component.html',
  styleUrls: ['./historique-signalement.component.css']
})
export class HistoriqueSignalementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
