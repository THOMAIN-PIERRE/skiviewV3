import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-neige',
  templateUrl: './neige.component.html',
  styleUrls: ['./neige.component.css']
})
export class NeigeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
