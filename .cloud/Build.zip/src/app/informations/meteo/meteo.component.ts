import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-meteo',
  templateUrl: './meteo.component.html',
  styleUrls: ['./meteo.component.css']
})
export class MeteoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
