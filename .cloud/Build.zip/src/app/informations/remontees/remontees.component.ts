import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-remontees',
  templateUrl: './remontees.component.html',
  styleUrls: ['./remontees.component.css']
})
export class RemonteesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
