import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-pistes',
  templateUrl: './pistes.component.html',
  styleUrls: ['./pistes.component.css']
})
export class PistesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
