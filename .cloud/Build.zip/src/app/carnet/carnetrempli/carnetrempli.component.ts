import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-carnetrempli',
  templateUrl: './carnetrempli.component.html',
  styleUrls: ['./carnetrempli.component.css']
})
export class CarnetrempliComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
