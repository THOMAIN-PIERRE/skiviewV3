import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-creationcompte',
  templateUrl: './creationcompte.component.html',
  styleUrls: ['./creationcompte.component.css']
})
export class CreationcompteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
