import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-station',
  templateUrl: './station.component.html',
  styleUrls: ['./station.component.css']
})
export class StationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
