import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-cguappli',
  templateUrl: './cguappli.component.html',
  styleUrls: ['./cguappli.component.css']
})
export class CguappliComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
