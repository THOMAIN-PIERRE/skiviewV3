import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-gestionmail',
  templateUrl: './gestionmail.component.html',
  styleUrls: ['./gestionmail.component.css']
})
export class GestionmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
