import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-gestionmdp',
  templateUrl: './gestionmdp.component.html',
  styleUrls: ['./gestionmdp.component.css']
})
export class GestionmdpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
