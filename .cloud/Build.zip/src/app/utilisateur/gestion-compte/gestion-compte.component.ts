import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-gestion-compte',
  templateUrl: './gestion-compte.component.html',
  styleUrls: ['./gestion-compte.component.css']
})
export class GestionCompteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
