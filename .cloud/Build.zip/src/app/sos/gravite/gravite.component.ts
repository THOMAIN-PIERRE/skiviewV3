import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-gravite',
  templateUrl: './gravite.component.html',
  styleUrls: ['./gravite.component.css']
})
export class GraviteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
