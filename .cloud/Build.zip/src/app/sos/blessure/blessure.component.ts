import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-blessure',
  templateUrl: './blessure.component.html',
  styleUrls: ['./blessure.component.css']
})
export class BlessureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
