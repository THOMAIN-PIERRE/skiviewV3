import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-activite',
  templateUrl: './activite.component.html',
  styleUrls: ['./activite.component.css']
})
export class ActiviteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
