import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-appel',
  templateUrl: './appel.component.html',
  styleUrls: ['./appel.component.css']
})
export class AppelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
