import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-etat',
  templateUrl: './etat.component.html',
  styleUrls: ['./etat.component.css']
})
export class EtatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
