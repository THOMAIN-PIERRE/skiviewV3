import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-nature',
  templateUrl: './nature.component.html',
  styleUrls: ['./nature.component.css']
})
export class NatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
