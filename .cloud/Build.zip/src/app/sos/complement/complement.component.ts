import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ns-complement',
  templateUrl: './complement.component.html',
  styleUrls: ['./complement.component.css']
})
export class ComplementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
